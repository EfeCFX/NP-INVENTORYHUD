fx_version 'adamant'

game 'gta5'

client_scripts {
    'client.lua'
}
export "GetClosestNPC"
export "IsPedNearCoords"
export "isPed"
export "GroupRank"
export "GlobalObject"
export "retreiveBusinesses"