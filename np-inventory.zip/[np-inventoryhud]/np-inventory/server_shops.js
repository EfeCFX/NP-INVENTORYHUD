// function CourtHouse() {
//     var shopItems = [
//         { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
//     ];
//     return JSON.stringify(shopItems);
// }

function PoliceArmory() {
    var shopItems = [
        { item_id: "pistolammo", id: 0, name: "Shop", information: "{}", slot: 1, amount: 50 },
        { item_id: "rifleammo", id: 0, name: "Shop", information: "{}", slot: 2, amount: 50 },
        { item_id: "shotgunammo", id: 0, name: "Shop", information: "{}", slot: 3, amount: 50 },
        { item_id: "subammo", id: 0, name: "Shop", information: "{}", slot: 4, amount: 50 },
        { item_id: "binoculars", id: 0, name: "Shop", information: "{}", slot: 5, amount: 1 },
        { item_id: "armor", id: 0, name: "Shop", information: "{}", slot: 6, amount: 50 },
        { item_id: "3219281620", id: 0, name: "Shop", information: "{}", slot: 7, amount: 1 },
        { item_id: "1737195953", id: 0, name: "Shop", information: "{}", slot: 8, amount: 1 },
        { item_id: "911657153", id: 0, name: "Shop", information: "{}", slot: 9, amount: 1 },
        { item_id: "101631238", id: 0, name: "Shop", information: "{}", slot: 10, amount: 1 },
        { item_id: "radio", id: 0, name: "Shop", information: "{}", slot: 11, amount: 1 },
        { item_id: "2343591895", id: 0, name: "Shop", information: "{}", slot: 12, amount: 1 },
        { item_id: "IFAK", id: 0, name: "Shop", information: "{}", slot: 13, amount: 50 },
        { item_id: "watch", id: 0, name: "Shop", information: "{}", slot: 14, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function MedicArmory() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function MedicArmoryCiv() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function InMateLottery() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Craft", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function JailFood() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function JailWeapon() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function JailMeth() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function JailPhone() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Craft", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function JailSlushy() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Craft", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function Smelting() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

// stores
function ConvenienceStore() {
    var shopItems = [
        { item_id: "water", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1, price: 3 },
        { item_id: "mobilephone", id: 0, name: "Shop", information: "{}", slot: 2, amount: 1, price: 3 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 3, amount: 1, price: 3 },
        { item_id: "sandwich", id: 0, name: "Shop", information: "{}", slot: 4, amount: 1, price: 3 },
        { item_id: "ciggy", id: 0, name: "Shop", information: "{}", slot: 5, amount: 1, price: 3 },
        { item_id: "chips", id: 0, name: "Shop", information: "{}", slot: 6, amount: 1, price: 3 },
        { item_id: "donut", id: 0, name: "Shop", information: "{}", slot: 7, amount: 1, price: 3 },
        { item_id: "coffee", id: 0, name: "Shop", information: "{}", slot: 8, amount: 1, price: 3 },
        { item_id: "rollingpaper", id: 0, name: "Shop", information: "{}", slot: 9, amount: 1, price: 3 },
        { item_id: "foodingredient", id: 0, name: "Shop", information: "{}", slot: 10, amount: 1, price: 3 },
    ];
    return JSON.stringify(shopItems);
}

function HardwareStore() {
    var shopItems = [
        { item_id: "repairkit", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1, price: 2},
        { item_id: "oxygentank", id: 0, name: "Shop", information: "{}", slot: 2, amount: 1, price: 2},
        { item_id: "heavycutters", id: 0, name: "Shop", information: "{}", slot: 3, amount: 1, price: 2},
        { item_id: "drill", id: 0, name: "Shop", information: "{}", slot: 4, amount: 1, price: 2},
        { item_id: "nitrous", id: 0, name: "Shop", information: "{}", slot: 5, amount: 1, price: 2},
        { item_id: "armor", id: 0, name: "Shop", information: "{}", slot: 6, amount: 1, price: 2},
        { item_id: "scanner", id: 0, name: "Shop", information: "{}", slot: 7, amount: 1, price: 2},
        { item_id: "advlockpick", id: 0, name: "Shop", information: "{}", slot: 8, amount: 1, price: 2},
        { item_id: "advrepairkit", id: 0, name: "Shop", information: "{}", slot: 9, amount: 1, price: 2},
        { item_id: "radio", id: 0, name: "Shop", information: "{}", slot: 10, amount: 1, price: 2},
        { item_id: "umbrella", id: 0, name: "Shop", information: "{}", slot: 11, amount: 1, price: 2},
        { item_id: "smallscales", id: 0, name: "Shop", information: "{}", slot: 12, amount: 1, price: 2},
        { item_id: "qualityscales", id: 0, name: "Shop", information: "{}", slot: 13, amount: 1, price: 2},
        { item_id: "heavydutydrill", id: 0, name: "Shop", information: "{}", slot: 14, amount: 1, price: 2},
        { item_id: "fertilizer", id: 0, name: "Shop", information: "{}", slot: 15, amount: 1, price: 2},
        { item_id: "Suitcase", id: 0, name: "Shop", information: "{}", slot: 16, amount: 1, price: 2},
        { item_id: "Boombox", id: 0, name: "Shop", information: "{}", slot: 17, amount: 1, price: 2},
        { item_id: "Box", id: 0, name: "Shop", information: "{}", slot: 18, amount: 1, price: 2},
        { item_id: "DuffelBag", id: 0, name: "Shop", information: "{}", slot: 19, amount: 1, price: 2},
        { item_id: "MedicalBag", id: 0, name: "Shop", information: "{}", slot: 20, amount: 1, price: 2},
    ];
    return JSON.stringify(shopItems);
}

function BurgiesStore() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
}

function GangStore() {
    var shopItems = [
          { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
}

function GangRepStore() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
};

function TacoTruck() {
    var shopItems = [
          { item_id: "icecream", id: 0, name: "craft", information: "{}", slot: 1, amount: 1 },
          { item_id: "hotdog", id: 0, name: "craft", information: "{}", slot: 2, amount: 1 },
          { item_id: "water", id: 0, name: "craft", information: "{}", slot: 3, amount: 1 },
          { item_id: "greencow", id: 0, name: "craft", information: "{}", slot: 4, amount: 1 },
          { item_id: "donut", id: 0, name: "craft", information: "{}", slot: 5, amount: 1 },
          { item_id: "eggsbacon", id: 0, name: "craft", information: "{}", slot: 6, amount: 1 },
          { item_id: "hamburger", id: 0, name: "craft", information: "{}", slot: 7, amount: 1 },
          { item_id: "burrito", id: 0, name: "craft", information: "{}", slot: 8, amount: 1 },
          { item_id: "coffee", id: 0, name: "craft", information: "{}", slot: 9, amount: 1 },
          { item_id: "sandwich", id: 0, name: "craft", information: "{}", slot: 10, amount: 1 },
          { item_id: "fishtaco", id: 0, name: "craft", information: "{}", slot: 11, amount: 1 },
          { item_id: "mshake", id: 0, name: "craft", information: "{}", slot: 12, amount: 1 },
          { item_id: "taco", id: 0, name: "craft", information: "{}", slot: 13, amount: 1 },
          { item_id: "churro", id: 0, name: "craft", information: "{}", slot: 14, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}

function Workshop() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
};

function GunStore() {
    var shopItems = [
        { item_id: "-1075685676", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "pistolammo", id: 0, name: "Shop", information: "{}", slot: 2, amount: 5 },
        { item_id: "2343591895", id: 0, name: "Shop", information: "{}", slot: 3, amount: 1 },
        { item_id: "2508868239", id: 0, name: "Shop", information: "{}", slot: 4, amount: 1 },
        { item_id: "2227010557", id: 0, name: "Shop", information: "{}", slot: 5, amount: 1 },
        //{ item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 6, amount: 1 },
    ];
    return JSON.stringify(shopItems);
};


function CraftRifleStoreGangs() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
};

function CraftBikerStoreGangs() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Shop", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
};

function CraftRifleCivilians() {
    var shopItems = [
        { item_id: "idcard", id: 0, name: "Craft", information: "{}", slot: 1, amount: 1 },
        { item_id: "bandage", id: 0, name: "Shop", information: "{}", slot: 2, amount: 2 },
    ];
    return JSON.stringify(shopItems);
}

function CraftRiflesStoreGang(){
    var shopItems = [
        { item_id: "silencer_l", id: 0, name: "Craft", information: "{}", slot: 1, amount: 1 },
        { item_id: "silencer_l2", id: 0, name: "Craft", information: "{}", slot: 2, amount: 1 },
        { item_id: "silencer_s", id: 0, name: "Craft", information: "{}", slot: 3, amount: 1 },
        { item_id: "silencer_s2", id: 0, name: "Craft", information: "{}", slot: 4, amount: 1 },
        //{ item_id: "silencer_l2", id: 0, name: "Craft", information: "{}", slot: 3, amount: 1 },
    ];
    return JSON.stringify(shopItems);
}